class Rectangle:
    def __init__(self, longueur, largeur):
        self.name = "Rectangle"
        self.longueur = longueur
        self.largeur = largeur
    
    def perimetre(self):
        return (self.longueur + self.largeur) * 2
    
    def aire(self):
        return self.longueur * self.largeur
    
    def __str__(self):
        return f"Pour un {self.name}, périmètre: {self.perimetre()} et aire: {self.aire()}"

class Carre(Rectangle):
    """
    Un carré est un rectangle particulier
    """
    def __init__(self, c):
        super().__init__(c, c)
        self.name = "Carré"

rectangle = Rectangle(5, 3)
print(rectangle)

c = Carre(5)
print(c)

