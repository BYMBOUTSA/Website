# Rédiger un programme compteurVoyelle.py constitué des deux fonctions suivantes :
#   1. Une fonction testVoyelle, dont le paramètre d’entrée est un caractère, qui renvoie T rue si le caractère est une
#      voyelle et F alse sinon.
#   2. Une fonction comptVoyelle, dont le paramètre d’entrée est une chaine de caractères, qui renvoie le nombre de
#      caractères qui sont des voyelles. Indication : une variable k parcourt la chaine de caractère reçue en argument ;
#      un compteur s’incrémente à chaque fois que k tombe sur une voyelle : le test est réalisé à l’aide de la fonction
#      précédente.
#
# Votre programme demande à l’utilisateur de saisir une chaine de caractères et lui répond le nombre de voyelles contenues
# dans la chaine.
#
# Remarque. Il est possible de définir une ou plusieurs fonctions dans un premier fichier texte et d’y faire appel dans
# un autre script. Attention : pour ne pas avoir à spécifier le chemin d’accès, il est préférable de placer les deux scripts
# dans un même dossier. Pour accéder aux fonctions placées dans un autre fichier on utilise la même syntaxe que pour les
# modules prédéfinis avec le mot clé import et le nom du fichier.
