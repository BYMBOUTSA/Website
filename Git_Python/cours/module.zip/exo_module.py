# Faire un module affichage_divers qui contient la fonction afficher_somme qui prends en paramètre un entier n et qui affiche la somme de 0 à n.
# Ajoutez à ce module, la fonction afficher_moyenne qui prends en paramètres deux entiers et qui affiche leurs moyennes.
# Faire un programme qui utilise le module affichage_divers et qui affiche la somme des entier de 0 à 201, et qui affiche la moyenne entre 12.2 et 14.3.
