class Phone:

    # number est une variable de classe à ne pas confondre
    # avec une variable d'instance (ex. self.model)
    number = 0  # 0 phone created

    def __new__(cls):
        """
        Création de l'objet
        """
        photo = super().__new__(cls)  # Création de l'instance
        Phone.number += 1  # Incrémentation de ma variable de classe number
        return photo  # retourne l'instance

    def __init__(self):  # Ne pas confondre avec __new__
        """
        Initialisation de l'objet
        """
        self.serial_number = "123NouzironAuBois456DesCerises"
        self.code_pin = "1234"
        self.model = "nokai"
        self.number_phone = "06 06 06 06 06"

    @staticmethod
    def search_network():
        """
        Méthode de recherche de réseau
        :return: None
        """
        print("Réseau FSR, bienvenue dans un monde meilleur..")

    @staticmethod
    def get_message():
        """
        Afficher les nouveaux SMS
        :return: None
        """
        print("Vous n'avez pas de message")
        print("Achetez les corn flakes Snapk")

    def switch_on(self, code_pin):
        """
        Affiche si le code Pin est correct
        Affiche les messages
        :param code_pin: string
        :return: None
        """
        print(self.model)
        if code_pin == self.code_pin:
            print("Tu ti Tu Ti")
            self.search_network()
            self.get_message()
        else:
            print("mauvais code pin")


class PhoneWithPhoto(Phone):

    @staticmethod
    def take_photo():
        print("clik-clak")


class BestPhoneWithPhoto(PhoneWithPhoto):

    @staticmethod
    def make_coffee():
        print("plik, plik, plik")

    @staticmethod
    def get_message():
        """
        Afficher les nouveaux SMS
        :return: None
        """
        print("Vous n'avez pas de message")
        print("Achetez les chocapics")


phone_of_me = Phone()
print(phone_of_me.serial_number)
phone_of_me.get_message()
print(f"{Phone.number} phone(s) created)")

phone_of_alone = PhoneWithPhoto()
phone_of_alone.get_message()
print(f"{Phone.number} phone(s) created)")

phone_of_you = BestPhoneWithPhoto()
print(phone_of_you.serial_number)
phone_of_you.get_message()
print(f"{Phone.number} phone(s) created)")
