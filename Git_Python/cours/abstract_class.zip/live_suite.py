from abc import abstractmethod, ABCMeta


class Product:

    def __new__(cls):
        product = super().__new__(cls)
        product.name = cls.__name__
        return product

    @abstractmethod
    def get_name_of_product(self):
        pass


class CornFlakes(Product):

    def get_name_of_product(self):
        return self.name


class Chocapic(Product):

    def get_name_of_product(self):
        return self.name


p = Product()

product_1 = CornFlakes()
product_1_name = product_1.get_name_of_product()
print(product_1_name)

product_2 = Chocapic()
product_2_name = product_2.get_name_of_product()
print(product_2_name)
